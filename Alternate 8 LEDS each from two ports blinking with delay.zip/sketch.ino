void setup() {
  volatile long*da;
  volatile long*db;
  da=0x21;
  *da=0xff;
  db=0x24;
  *db=0xff;

}

void layer1(long x){
  volatile long*a;
  a=0x22;
  *a=x;
}
void layer2(long x){
  volatile long*b;
  b=0x25;
  *b=x;
}
void loop(){
  volatile long i;
  long x;
  x=0x55;
  layer1(x);
  for(i=0;i<100000;i++);
  layer1(0);
  for(i=0;i<100000;i++);
  x=0xaa;
  layer2(x);
  for(i=0;i<100000;i++);
  layer2(0);
  for(i=0;i<100000;i++);
  x=0x55;
  layer2(x);
  for(i=0;i<100000;i++);
  layer2(0);
  for(i=0;i<100000;i++);
  x=0xaa;
  layer1(x);
  for(i=0;i<100000;i++);
  layer1(0);
  for(i=0;i<100000;i++);

}
